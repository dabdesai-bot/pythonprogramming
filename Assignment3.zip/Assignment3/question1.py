def multiplication(a,b):
    mult=a*b;
    return mult

x=0
y=0
result=0
x=int(input("enter the number"))
y=int(input("enter the number"))

result=multiplication(x,y)

print("multiplication is:",result)