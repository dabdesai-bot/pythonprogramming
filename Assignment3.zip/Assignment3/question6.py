import sys

x=12
print(x)
print(type(x))
print(id(x))
print(sys.getsizeof(x))