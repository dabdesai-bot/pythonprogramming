a=5
print(type(a))
a=5.5
print(type(a))
a="python"
print(type(a))