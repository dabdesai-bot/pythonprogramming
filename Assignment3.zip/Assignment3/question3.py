def fun():
    x=10
    print(x)

fun()
print(x)