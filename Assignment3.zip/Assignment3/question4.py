def fun():
    print("funny thing")

def main():
    fun()

if __name__=="__main__":
    main()